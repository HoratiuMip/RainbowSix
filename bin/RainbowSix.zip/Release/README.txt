RainbowSix - same adrenaline, no violence

Do not remove or change the name of files. You may replace the sounds and images, but keep the name.

Controls:
	
	ESC - quit
	LMB - go there
	M   - mute/unmute sounds

Default settings:

	spirdus_speed:        2.2
	rainbow_build_time:   1.0
	gold_show_time:       1.1
	gold_dark_rad:        540.0  
	rainbow_spawn_rate:   3

-mip